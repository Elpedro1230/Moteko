
import javax.swing.*;
import java.awt.*;

public class LoginMoteko extends JFrame {

    public LoginMoteko() {
        setTitle("Moteko - Inicio de Sesión");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(400, 600);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(255, 149, 0));
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel();
        mainPanel.setOpaque(false);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));

        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setOpaque(false);

        ImageIcon icono = new ImageIcon(getClass().getResource("/sources/logo.png"));
        Image imagen = icono.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
        ImageIcon iconoEscalado = new ImageIcon(imagen);
        JLabel lblLogo = new JLabel(iconoEscalado);
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);

        logoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        logoPanel.add(lblLogo);
        logoPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 30, 0));

        mainPanel.add(logoPanel);

        JTextField txtUsuario = new JTextField();
        txtUsuario.setMaximumSize(new Dimension(300, 40));
        txtUsuario.setBorder(BorderFactory.createTitledBorder("Usuario"));
        mainPanel.add(txtUsuario);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JPasswordField txtClave = new JPasswordField();
        txtClave.setMaximumSize(new Dimension(300, 40));
        txtClave.setBorder(BorderFactory.createTitledBorder("Contraseña"));
        mainPanel.add(txtClave);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        JLabel lblOlvido = new JLabel("¿Olvidaste contraseña?");
        lblOlvido.setForeground(Color.BLUE);
        lblOlvido.setAlignmentX(Component.CENTER_ALIGNMENT);
        lblOlvido.setFont(new Font("Arial", Font.PLAIN, 12));
        mainPanel.add(lblOlvido);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 20)));

        JButton btnLogin = new JButton("INICIAR SESIÓN");
        btnLogin.setBackground(Color.BLACK);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setMaximumSize(new Dimension(200, 40));
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(btnLogin);
        mainPanel.add(Box.createRigidArea(new Dimension(0, 15)));

        JButton btnCrear = new JButton("Crear cuenta");
        btnCrear.setMaximumSize(new Dimension(150, 35));
        btnCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(btnCrear);

        add(mainPanel, BorderLayout.CENTER);

        btnCrear.addActionListener(e -> {
            CrearCuenta crearCuenta = new CrearCuenta();
            crearCuenta.setVisible(true);
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginMoteko ventana = new LoginMoteko();
            ventana.setExtendedState(JFrame.MAXIMIZED_BOTH);
            ventana.setVisible(true);
        });
    }

}
