import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MenuMoteko extends JFrame {

    public MenuMoteko() {
        setTitle("Menú Moteko");
        setSize(320, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setUndecorated(true); // Sin borde

        Color fondoNaranja = new Color(255, 149, 0); // #FF9500
        Color colorTexto = Color.WHITE;
        Color hoverColor = new Color(255, 180, 50); // Efecto al pasar el mouse

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(fondoNaranja);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Padding interno

        // Etiqueta de perfil
        JLabel lblUsuario = new JLabel("Usuario - Mi perfil >");
        lblUsuario.setForeground(colorTexto);
        lblUsuario.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblUsuario.setAlignmentX(Component.LEFT_ALIGNMENT);
        panel.add(lblUsuario);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));

        // Botones del menú
        String[] opciones = {
            "Moteko Pago >", "Inicio", "Buscar", "Notificaciones",
            "Ayuda / PQR", "Mis compras", "Favoritos", "Ofertas",
            "Cupones", "Moteko Sale", "Productos", "Mi cuenta",
            "Categorías", "Venta", "Cerrar sesión", "Acerca de Moteko"
        };

        for (String texto : opciones) {
            JButton btn = crearBotonEstilizado(texto, fondoNaranja, colorTexto, hoverColor);
            panel.add(btn);
            panel.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        add(panel);
        setVisible(true);
    }

    private JButton crearBotonEstilizado(String texto, Color bgColor, Color fgColor, Color hoverColor) {
        JButton btn = new JButton(texto);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setBackground(bgColor);
        btn.setForeground(fgColor);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btn.setAlignmentX(Component.LEFT_ALIGNMENT);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12)); // Padding

        // Efecto hover
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(hoverColor);
            }

            public void mouseExited(MouseEvent e) {
                btn.setBackground(bgColor);
            }
        });

        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuMoteko());
    }
}
