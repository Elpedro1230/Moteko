
import javax.swing.*;
import java.awt.*;

public class CrearCuenta extends JFrame {

    public CrearCuenta() {
        setTitle("Moteko - Crear Cuenta");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400, 600);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(255, 149, 0));
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        String[] etiquetas = {
            "Nombres", "Apellidos", "Identificación",
            "Teléfono", "Dirección", "Email"
        };

        for (String texto : etiquetas) {
            JTextField campo = new JTextField();
            campo.setMaximumSize(new Dimension(300, 40));
            campo.setBorder(BorderFactory.createTitledBorder(texto));
            panel.add(campo);
            panel.add(Box.createRigidArea(new Dimension(0, 10)));
        }

        JButton btnCrear = new JButton("Crear cuenta");
        btnCrear.setMaximumSize(new Dimension(200, 40));
        btnCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnCrear);

        add(panel, BorderLayout.CENTER);
    }
}
