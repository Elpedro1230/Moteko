package mainapp;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Purchase {

    private List<Product> items;
    private double total;
    private Date purchaseDate;

    public Purchase(List<Product> items, double total) {
        this.items = new ArrayList<>(items);
        this.total = total;
        this.purchaseDate = new Date();
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public List<Product> getItems() {
        return items;
    }

    public double getTotal() {
        return total;
    }

    @Override
    public String toString() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy");
        StringBuilder sb = new StringBuilder(sdf.format(purchaseDate) + "\n");
        for (Product p : items) {
            sb.append(p.getName()).append(" (Repuestos) $").append(p.getPrice()).append("\n");
        }
        sb.append("Total: $").append(total);
        return sb.toString();
    }

    public String toFileString() {
        StringBuilder sb = new StringBuilder();
        sb.append(purchaseDate.getTime()).append("|").append(total).append("|");
        for (Product p : items) {
            sb.append(p.getId()).append(","); // Usar coma como separador
        }
        // Eliminar la última coma si hay items
        if (!items.isEmpty()) {
            sb.deleteCharAt(sb.length() - 1);
        }
        return sb.toString();
    }

// Nuevo método estático para reconstruir desde string
    public static Purchase fromFileString(String str, List<Product> inventory) {
        String[] parts = str.split("\\|");
        Date date = new Date(Long.parseLong(parts[0]));
        double total = Double.parseDouble(parts[1]);
        List<Product> items = new ArrayList<>();

        if (parts.length > 2 && !parts[2].isEmpty()) {
            String[] productIds = parts[2].split(",");
            for (String idStr : productIds) {
                int id = Integer.parseInt(idStr);
                for (Product p : inventory) {
                    if (p.getId() == id) {
                        items.add(p);
                        break;
                    }
                }
            }
        }

        return new Purchase(items, total);
    }
}
