package mainapp;

import javax.swing.*;
import java.awt.*;

public class LoginPanel extends JPanel {

    private MainApp mainFrame;
    private JTextField txtUsuario;
    private JPasswordField txtClave;

    public LoginPanel(MainApp frame) {
        this.mainFrame = frame;
        setOpaque(false);
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));

        JPanel logoPanel = new JPanel();
        logoPanel.setLayout(new BoxLayout(logoPanel, BoxLayout.Y_AXIS));
        logoPanel.setOpaque(false);

        ImageIcon icono = new ImageIcon(getClass().getResource("/sources/logo.png"));
        Image imagen = icono.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
        ImageIcon iconoEscalado = new ImageIcon(imagen);
        JLabel lblLogo = new JLabel(iconoEscalado);
        lblLogo.setAlignmentX(Component.CENTER_ALIGNMENT);
        logoPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        logoPanel.add(lblLogo);
        logoPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 30, 0));
        add(logoPanel);

        txtUsuario = new JTextField();
        txtUsuario.setMaximumSize(new Dimension(300, 40));
        txtUsuario.setBorder(BorderFactory.createTitledBorder("Usuario"));
        add(txtUsuario);
        add(Box.createRigidArea(new Dimension(0, 10)));

        txtClave = new JPasswordField();
        txtClave.setMaximumSize(new Dimension(300, 40));
        txtClave.setBorder(BorderFactory.createTitledBorder("Contraseña"));
        add(txtClave);
        add(Box.createRigidArea(new Dimension(0, 10)));

        JButton btnLogin = new JButton("INICIAR SESIÓN");
        btnLogin.setBackground(Color.BLACK);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setMaximumSize(new Dimension(200, 40));
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.addActionListener(e -> handleLogin());
        add(btnLogin);
        add(Box.createRigidArea(new Dimension(0, 15)));

        JButton btnCrear = new JButton("Crear cuenta");
        btnCrear.setMaximumSize(new Dimension(150, 35));
        btnCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCrear.addActionListener(e -> new RegisterPanel(mainFrame).setVisible(true));
        add(btnCrear);
    }

    private void handleLogin() {
        String username = txtUsuario.getText();
        String password = new String(txtClave.getPassword());

        if (UserManager.validateUser(username, password)) {
            MainApp.currentUser = username;
            if (username.equals("admin")) {
                mainFrame.showAdminPanel();
            } else {
                mainFrame.showUserPanel();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Credenciales inválidas!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
