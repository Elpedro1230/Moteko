package mainapp;

import java.util.List;
import java.util.ArrayList;

public class PurchaseManager {

    private static final String PURCHASES_FILE = "Purchases.txt";

    public static void savePurchase(Purchase purchase, String user) {
        List<String> lines = FileUtils.readFromFile(user+PURCHASES_FILE);
        lines.add(purchase.toFileString());
        FileUtils.saveToFile(user+PURCHASES_FILE, lines);
    }

    public static List<Purchase> loadPurchases(List<Product> inventory, String user) {
        List<Purchase> purchases = new ArrayList<>();
        List<String> lines = FileUtils.readFromFile(user+PURCHASES_FILE);

        for (String line : lines) {
            purchases.add(Purchase.fromFileString(line, inventory));
        }

        return purchases;
    }
}
