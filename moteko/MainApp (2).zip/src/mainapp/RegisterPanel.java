package mainapp;

import javax.swing.*;
import java.awt.*;

public class RegisterPanel extends JFrame {

    public RegisterPanel(MainApp frame) {
        setTitle("Moteko - Crear Cuenta");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(400, 240);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(255, 149, 0));
        setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 50, 30, 50));

        String[] etiquetas = {"Usuario", "Contraseña"};

        JTextField userField = new JTextField();
        userField.setMaximumSize(new Dimension(300, 40));
        userField.setBorder(BorderFactory.createTitledBorder(etiquetas[0]));
        panel.add(userField);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JTextField passwordField = new JTextField();
        passwordField.setMaximumSize(new Dimension(300, 40));
        passwordField.setBorder(BorderFactory.createTitledBorder(etiquetas[1]));
        panel.add(passwordField);
        panel.add(Box.createRigidArea(new Dimension(0, 10)));

        JButton btnCrear = new JButton("Crear cuenta");
        btnCrear.setMaximumSize(new Dimension(200, 40));
        btnCrear.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnCrear.addActionListener(e -> {
            String username = userField.getText();
            String password = passwordField.getText();
            UserManager.createUser(username, password);
            JOptionPane.showMessageDialog(this, "Cuenta creada exitosamente!");
            dispose();
            frame.showLoginPanel();
        });
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(btnCrear);

        add(panel, BorderLayout.CENTER);
    }
}
