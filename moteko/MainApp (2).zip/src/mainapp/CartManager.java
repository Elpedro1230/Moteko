package mainapp;

import java.util.List;
import java.util.ArrayList;

public class CartManager {

    private static final String CART_FILE = "Cart.txt";

    public static void saveToCart(Product product, String user) {
        List<String> lines = FileUtils.readFromFile(user + CART_FILE);
        lines.add(product.toFileString());
        FileUtils.saveToFile(user + CART_FILE, lines);
    }

    public static List<Product> loadCart(String user) {
        List<Product> products = new ArrayList<>();
        List<String> lines = FileUtils.readFromFile(user + CART_FILE);

        for (String line : lines) {
            products.add(Product.fromFileString(line));
        }

        return products;
    }

    public static void clearCart(String user) {
        List<String> lines = new ArrayList();
        FileUtils.saveToFile(user + CART_FILE, lines);
    }
}
