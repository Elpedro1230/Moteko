package mainapp;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class UserPanel extends JPanel {

    private MainApp mainFrame;
    private JTextArea displayArea;
    private List<Product> inventory = new ArrayList<>();
    private List<Product> cart = new ArrayList<>();
    private List<Product> wishlist = new ArrayList<>();
    private List<Purchase> purchaseHistory = new ArrayList<>();

    public UserPanel(MainApp frame) {
        this.mainFrame = frame;
        setOpaque(false);
        setLayout(new BorderLayout());

        inventory = InventoryManager.loadInventory();
        purchaseHistory = PurchaseManager.loadPurchases(inventory, MainApp.currentUser);
        wishlist = FavoriteManager.loadFavorites(MainApp.currentUser);
        cart = CartManager.loadCart(MainApp.currentUser);

        displayArea = new JTextArea(10, 50);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Arial", Font.PLAIN, 24)); // Ajusta el tamaño de fuente aquí
        displayArea.setBackground(new Color(255, 149, 0)); // Color de fondo
        displayArea.setForeground(Color.BLACK); // Color del texto
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 7));
        JButton agrCarritoButton = new JButton("Agregar al carrito");
        JButton inicioButton = new JButton("Inicio");
        JButton buscarButton = new JButton("Buscar");
        JButton comprasButton = new JButton("Carrito");
        JButton limpiarButton = new JButton("Limpiar Carrito/Favoritos");
        JButton favoritosButton = new JButton("Favoritos");
        JButton historialButton = new JButton("Historial");
        JButton cerrarButton = new JButton("Cerrar sesión");

        buttonPanel.add(agrCarritoButton);
        buttonPanel.add(inicioButton);
        buttonPanel.add(buscarButton);
        buttonPanel.add(comprasButton);
        buttonPanel.add(limpiarButton);
        buttonPanel.add(favoritosButton);
        buttonPanel.add(historialButton);
        buttonPanel.add(cerrarButton);

        agrCarritoButton.addActionListener(e -> addToCart());
        inicioButton.addActionListener(e -> displayProducts());
        buscarButton.addActionListener(e -> searchProducts());
        comprasButton.addActionListener(e -> viewCart());
        limpiarButton.addActionListener(e -> limpiar());
        favoritosButton.addActionListener(e -> viewWishlist());
        historialButton.addActionListener(e -> viewHistory());
        cerrarButton.addActionListener(e -> mainFrame.showLoginPanel());

        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        displayProducts();
    }

    private void displayProducts() {
        StringBuilder sb = new StringBuilder("Productos (Últimos 90 días):\n");
        for (Product p : inventory) {
            sb.append(p.toString()).append("\n");
        }
        displayArea.setText(sb.toString());
    }

    private void searchProducts() {
        String search = JOptionPane.showInputDialog(this, "Buscar producto:");
        if (search != null) {
            StringBuilder sb = new StringBuilder("Resultados de búsqueda:\n");
            boolean found = false;
            for (Product p : inventory) {
                if (p.getName().toLowerCase().contains(search.toLowerCase())) {
                    sb.append(p.toString()).append("\n");
                    found = true;
                }
            }
            displayArea.setText(found ? sb.toString() : "No se encontraron productos.");
        }
    }

    private void addToCart() {
        String input = JOptionPane.showInputDialog(this, "ID del producto para agregar al carrito:");
        if (input != null) {
            try {
                int id = Integer.parseInt(input);
                Product product = inventory.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
                if (product != null) {
                    cart.add(product);
                    CartManager.saveToCart(product, MainApp.currentUser);
                    JOptionPane.showMessageDialog(this, product.getName() + " agregado al carrito!");
                    int choice = JOptionPane.showConfirmDialog(this, "¿Agregar a favoritos también?", "Favoritos", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) {
                        wishlist.add(product);
                        JOptionPane.showMessageDialog(this, product.getName() + " agregado a favoritos!");
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Producto no encontrado!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID inválido!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // El usuario hizo clic en Cancelar o cerró la ventana
            JOptionPane.showMessageDialog(this, "Operación cancelada por el usuario.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void viewCart() {
        if (cart.isEmpty()) {
            displayArea.setText("Carrito vacío.");
            return;
        }
        StringBuilder sb = new StringBuilder("Moteko Sales Carrito:\n");
        int[] quantities = new int[inventory.size()];
        for (Product p : cart) {
            quantities[p.getId() - 1]++;
        }
        double total = 0;
        for (int i = 0; i < inventory.size(); i++) {
            if (quantities[i] > 0) {
                Product p = inventory.get(i);
                sb.append(p.getName()).append(" (Repuestos) $").append(p.getPrice()).append(" x").append(quantities[i]).append("\n").append("\n");
                total += p.getPrice() * quantities[i];
            }
        }
        sb.append("Total: ").append(total).append("\n");
        displayArea.setText(sb.toString());

        int choice = JOptionPane.showConfirmDialog(this, "¿Proceder al pago?", "Checkout", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            purchaseHistory.add(new Purchase(cart, total));
            PurchaseManager.savePurchase(new Purchase(cart, total), MainApp.currentUser);
            cart.clear();
            CartManager.clearCart(MainApp.currentUser);
            JOptionPane.showMessageDialog(this, "Compra completada!");
            displayArea.setText("Carrito limpiado después de la compra.");
        }
    }

    private void limpiar() {
        Object[] options = {"Carrito", "Favoritos"};

        int choice = JOptionPane.showOptionDialog(this, "¿Qué lista desea limpiar?", "Limpieza", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (choice == JOptionPane.NO_OPTION) {
            FavoriteManager.clearFavorites(MainApp.currentUser);
            JOptionPane.showMessageDialog(this, "se ha vaciado la lista de favoritos");
        } else if (choice == JOptionPane.YES_OPTION) {
            CartManager.clearCart(MainApp.currentUser);
            JOptionPane.showMessageDialog(this, "se ha vaciado el carrito");

        }
    }

    private void viewWishlist() {
        if (wishlist.isEmpty()) {
            displayArea.setText("Lista de deseos vacía. (Fin de la lista de deseos)");
            return;
        }
        StringBuilder sb = new StringBuilder("Lista de deseos:\n");
        for (Product p : wishlist) {
            sb.append(p.toString()).append("\n");
        }
        sb.append("Fin de la lista de deseos");
        displayArea.setText(sb.toString());
    }

    private void viewHistory() {
        if (purchaseHistory.isEmpty()) {
            displayArea.setText("Sin historial de compras. (Fin del historial)");
            return;
        }
        StringBuilder sb = new StringBuilder("Historial de compras (Últimos 90 días):\n");
        for (Purchase p : purchaseHistory) {
            sb.append(p.toString()).append("\n").append("\n");
        }
        sb.append("Fin del historial");
        displayArea.setText(sb.toString());
    }
}
