package mainapp;

import java.util.List;
import java.util.ArrayList;

public class FavoriteManager {

    private static final String FAVORITES_FILE = "Favorites.txt";

    public static void saveFavorite(Product product, String user) {
        List<String> lines = FileUtils.readFromFile(user + FAVORITES_FILE);
        lines.add(product.toFileString());
        FileUtils.saveToFile(user + FAVORITES_FILE, lines);
    }

    public static List<Product> loadFavorites(String user) {
        List<Product> products = new ArrayList<>();
        List<String> lines = FileUtils.readFromFile(user + FAVORITES_FILE);

        for (String line : lines) {
            products.add(Product.fromFileString(line));
        }

        return products;
    }

    public static void clearFavorites(String user) {
        List<String> lines = new ArrayList();
        FileUtils.saveToFile(user + FAVORITES_FILE, lines);
    }
}
