package mainapp;

import java.util.List;
import java.util.ArrayList;

public class UserManager {

    private static final String USERS_FILE = "users.txt";

    public static boolean validateUser(String username, String password) {
        List<String> lines = FileUtils.readFromFile(USERS_FILE);

        for (String line : lines) {
            String[] parts = line.split("\\|");
            if (parts[0].equals(username) && parts[1].equals(password)) {
                return true;
            }
        }

        // Usuarios por defecto si el archivo está vacío
        if (lines.isEmpty()) {
            createDefaultUsers();
            return validateUser(username, password);
        }

        return false;
    }

    private static void createDefaultUsers() {
        List<String> lines = new ArrayList<>();
        lines.add("admin|admin123|admin");
        lines.add("user|user123|user");
        FileUtils.saveToFile(USERS_FILE, lines);
    }

    public static void createUser(String user, String password) {
        List<String> lines = FileUtils.readFromFile(USERS_FILE);
        // Usuarios por defecto si el archivo está vacío
        if (lines.isEmpty()) {
            createDefaultUsers();
        }
        lines.add(user+"|"+password+"|user");
        FileUtils.saveToFile(USERS_FILE, lines);
    }
}
