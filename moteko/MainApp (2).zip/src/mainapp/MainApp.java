/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mainapp;

/**
 *
 * @author julia
 */
import javax.swing.*;
import java.awt.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class MainApp extends JFrame {

    private LoginPanel loginPanel;
    public static String currentUser = new String();

    public MainApp() {
        UIManager.put("Button.font", new Font("Arial", Font.BOLD, 14));
        UIManager.put("Label.font", new Font("Arial", Font.PLAIN, 14));
        UIManager.put("TextField.font", new Font("Arial", Font.PLAIN, 14));
        UIManager.put("TextArea.font", new Font("Arial", Font.PLAIN, 14));
        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.PLAIN, 14));

        setTitle("Moteko");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(255, 149, 0));
        setLayout(new BorderLayout());

        loginPanel = new LoginPanel(this);
        add(loginPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    public void showUserPanel() {
        remove(loginPanel);
        add(new UserPanel(this), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public void showAdminPanel() {
        remove(loginPanel);
        add(new AdminPanel(this), BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public void showLoginPanel() {
        remove(getContentPane().getComponent(0));
        loginPanel = new LoginPanel(this);
        add(loginPanel, BorderLayout.CENTER);
        revalidate();
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainApp::new);
    }
}
