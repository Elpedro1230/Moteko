package mainapp;

import java.util.ArrayList;
import java.util.List;

public class InventoryManager {
    private static final String INVENTORY_FILE = "inventory.txt";

    public static List<Product> loadInventory() {
        List<Product> inventory = new ArrayList<>();
        List<String> lines = FileUtils.readFromFile(INVENTORY_FILE);

        
        for (String line : lines) {
            inventory.add(Product.fromFileString(line));
        }
        // Si está vacío, carga los productos por defecto
        if (inventory.isEmpty()) {
            inventory.add(new Product(1, "Cilindro", 119.99));
            inventory.add(new Product(2, "Biela", 43.99));
            inventory.add(new Product(3, "Filtros", 54.99));
            inventory.add(new Product(4, "Llantas", 84.99));
            saveInventory(inventory);
        }
        
        return inventory;
    }

    public static void saveInventory(List<Product> inventory) {
        List<String> lines = new ArrayList<>();
        for (Product p : inventory) {
            lines.add(p.toFileString());
        }
        FileUtils.saveToFile(INVENTORY_FILE, lines);
    }
}