package mainapp;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class AdminPanel extends JPanel {

    private MainApp mainFrame;
    private JTextArea displayArea;
    private JTextField productNameField, productPriceField;
    private List<Product> inventory = new ArrayList<>();

    public AdminPanel(MainApp frame) {
        this.mainFrame = frame;
        setOpaque(false);
        this.mainFrame.setBackground(new Color(155, 150, 0));
        setLayout(new BorderLayout());

        inventory = InventoryManager.loadInventory();

        displayArea = new JTextArea(10, 50);
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Arial", Font.PLAIN, 24)); // Ajusta el tamaño de fuente aquí
        displayArea.setBackground(new Color(255, 149, 0)); // Color de fondo
        displayArea.setForeground(Color.BLACK); // Color del texto
        JScrollPane scrollPane = new JScrollPane(displayArea);

        JPanel inputPanel = new JPanel(new GridLayout(3, 2));
        JLabel nameLabel = new JLabel("Nombre del Producto:");
        productNameField = new JTextField(15);
        JLabel priceLabel = new JLabel("Precio del Producto:");
        productPriceField = new JTextField(15);
        inputPanel.add(nameLabel);
        inputPanel.add(productNameField);
        inputPanel.add(priceLabel);
        inputPanel.add(productPriceField);

        JPanel buttonPanel = new JPanel(new GridLayout(1, 4));
        JButton productButton = new JButton("Productos Disponibles");
        JButton addButton = new JButton("Agregar Producto");
        JButton removeButton = new JButton("Eliminar Producto");
        JButton logoutButton = new JButton("Cerrar sesión");

        buttonPanel.add(productButton);
        buttonPanel.add(addButton);
        buttonPanel.add(removeButton);
        buttonPanel.add(logoutButton);

        productButton.addActionListener(e -> displayProducts());
        addButton.addActionListener(e -> addProduct());
        removeButton.addActionListener(e -> removeProduct());
        logoutButton.addActionListener(e -> mainFrame.showLoginPanel());

        add(scrollPane, BorderLayout.CENTER);
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        displayProducts();
    }

    private void displayProducts() {
        StringBuilder sb = new StringBuilder("Productos (Últimos 90 días):\n");
        for (Product p : inventory) {
            sb.append(p.toString()).append("\n");
        }
        displayArea.setText(sb.toString());
    }

    private void addProduct() {
        try {
            String name = productNameField.getText();
            double price = Double.parseDouble(productPriceField.getText());
            int id = inventory.size() + 1;
            inventory.add(new Product(id, name, price));
            InventoryManager.saveInventory(inventory);
            JOptionPane.showMessageDialog(this, "Producto agregado: " + name);
            productNameField.setText("");
            productPriceField.setText("");
            displayProducts();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Precio inválido!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void removeProduct() {
        String input = JOptionPane.showInputDialog(this, "ID del producto para eliminar:");
        if (input != null) {
            try {
                int id = Integer.parseInt(input);
                Product product = inventory.stream().filter(p -> p.getId() == id).findFirst().orElse(null);
                if (product != null) {
                    inventory.remove(product);
                    InventoryManager.saveInventory(inventory);
                    JOptionPane.showMessageDialog(this, "Producto eliminado!");
                } else {
                    JOptionPane.showMessageDialog(this, "Producto no encontrado!", "Error", JOptionPane.ERROR_MESSAGE);
                }
                displayProducts();
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "ID inválido!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            // El usuario hizo clic en Cancelar o cerró la ventana
            JOptionPane.showMessageDialog(this, "Operación cancelada por el usuario.", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
