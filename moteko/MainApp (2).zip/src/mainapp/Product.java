package mainapp;

import java.util.Date;

public class Product {

    private int id;
    private String name;
    private double price;
    private Date addedDate;

    public Product(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.addedDate = new Date();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public Date getAddedDate() {
        return addedDate;
    }

    public String toFileString() {
        return id + "|" + name + "|" + price + "|" + addedDate.getTime();
    }

    public static Product fromFileString(String str) {
        String[] parts = str.split("\\|");
        Product p = new Product(Integer.parseInt(parts[0]), parts[1], Double.parseDouble(parts[2]));
        p.addedDate = new Date(Long.parseLong(parts[3]));
        return p;
    }

    @Override
    public String toString() {
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd MMM yyyy");
        return "\n" + sdf.format(addedDate) + "\n" + name + " (Repuestos) $" + price + " ♥"+" id:" +id;
    }
}
